package com.example.viewpagerrecycleview

class FriendList (
    val Nama:String,
    val Kelamin:String,
    val Email:String,
    val Phone:String,
    val Alamat:String
        )
