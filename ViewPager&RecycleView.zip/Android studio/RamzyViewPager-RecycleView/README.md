# RamzyViewPager-RecycleView
Aplikasi Android Sederhana dengan ViewPager&amp;RecycleView
